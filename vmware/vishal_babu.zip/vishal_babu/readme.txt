### Assignment ###
There are total 5 files mentioned below:
1. Modeling.ipynb : In this file You will get EDA and model training , test code.
2. Predict .py : You will get prediction code in this file.
3. test.csv : In this file you will get results of test data set.
4. lr_clf.sav : pickled logistic regression model
5. cv.sav  : pickled count vectorizer.
